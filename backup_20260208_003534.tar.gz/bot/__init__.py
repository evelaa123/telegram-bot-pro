"""Telegram Bot package."""
from bot.bot import create_bot, dp, bot

__all__ = ["create_bot", "dp", "bot"]
